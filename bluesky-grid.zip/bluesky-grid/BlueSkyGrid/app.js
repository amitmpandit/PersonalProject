﻿

// Start loading the main app file. 
requirejs(['main']);



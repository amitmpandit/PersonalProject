Library Project including Palette for color extraction from images
